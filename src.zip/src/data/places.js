export const places = {
  restaurants: [
    {
      id: 1,
      name: "Le Grand Restaurant",
      address: "123 rue de Paris",
      description: "Restaurant gastronomique avec vue panoramique",
      images: [
        "https://toohotel.com/wp-content/uploads/2022/09/TOO_restaurant_Panoramique_vue_Paris_Seine_Tour_Eiffel_2.jpg",
        "https://toohotel.com/wp-content/uploads/2022/09/TOO_restaurant_Panoramique_vue_Paris_Seine_Tour_Eiffel_2.jpg"
      ],
      virtualTourUrl: "/virtual-tours/grand-restaurant",
      rating: 4.5,
      features: ["Terrasse", "Vue panoramique", "Parking"],
      horaires: "10:00 - 23:00",
      price_range: "€€€"
    },
    {
      id: 2,
      name: "Le Petit Bistrot",
      address: "45 rue du Commerce",
      description: "Cuisine traditionnelle française dans un cadre chaleureux",
      images: [
        "https://media-cdn.tripadvisor.com/media/photo-s/1a/b8/46/6d/restaurant-guy-savoy-la.jpg",
        "https://media-cdn.tripadvisor.com/media/photo-s/1a/b8/46/6d/restaurant-guy-savoy-la.jpg"
      ],
      virtualTourUrl: "/virtual-tours/petit-bistrot",
      rating: 4.2,
      features: ["Cuisine maison", "Terrasse", "Menu du jour"],
      horaires: "12:00 - 22:00",
      price_range: "€€"
    }
  ],
  bars: [
    {
      id: 1,
      name: "Le Lounge Bar",
      address: "45 avenue des Champs-Élysées",
      description: "Bar moderne avec ambiance jazzy",
      images: [
        "/images/bars/lounge-1.jpg",
        "/images/bars/lounge-2.jpg"
      ],
      virtualTourUrl: "/virtual-tours/lounge-bar",
      rating: 4.2,
      features: ["Cocktails", "Musique live", "Happy Hour"],
      horaires: "18:00 - 02:00",
      price_range: "€€"
    }
    // Autres bars...
  ]
  // Autres catégories...
}; 