<template>
    <div class="p-6">
      <h1 class="text-3xl font-bold text-center">Magasins</h1>
      <p class="mt-4 text-lg text-gray-700">Liste des meilleurs bars à visiter.</p>
    </div>
  </template>
  
  <script>
  export default {
    name: "Bars",
  };
  </script>
  