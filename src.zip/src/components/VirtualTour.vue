<template>
  <div class="virtual-tour-container" ref="container">
    <!-- Le rendu Three.js sera ici -->
  </div>
</template>

<script>
import { onMounted, onUnmounted, ref } from 'vue';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';

export default {
  name: 'VirtualTour',
  props: {
    placeId: {
      type: String,
      required: true
    }
  },
  setup() {
    const container = ref(null);
    let scene, camera, renderer, controls;

    const init = () => {
      // Initialisation de Three.js
      scene = new THREE.Scene();
      camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
      renderer = new THREE.WebGLRenderer();
      
      container.value.appendChild(renderer.domElement);
      
      // Ajout des contrôles
      controls = new OrbitControls(camera, renderer.domElement);
      
      // Configuration de base
      camera.position.z = 5;
      
      // Animation
      const animate = () => {
        requestAnimationFrame(animate);
        controls.update();
        renderer.render(scene, camera);
      };
      
      animate();
    };

    onMounted(() => {
      init();
    });

    onUnmounted(() => {
      // Nettoyage
      scene.dispose();
      renderer.dispose();
    });

    return {
      container
    };
  }
};
</script>

<style scoped>
.virtual-tour-container {
  width: 100%;
  height: 100vh;
}
</style> 